﻿namespace MyCampusUI.Exceptions
{
    public class AssignmentSubmissionEvaluationException : ApplicationException
    {
        public AssignmentSubmissionEvaluationException(string message) : base(message)
        {
        }
    }
}
