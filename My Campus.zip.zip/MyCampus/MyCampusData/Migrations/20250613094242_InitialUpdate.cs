﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MyCampusData.Migrations
{
    public partial class InitialUpdate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Bundles",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    BundleSize = table.Column<long>(type: "bigint", nullable: false),
                    BundleFiles = table.Column<int>(type: "int", nullable: false),
                    ModifiedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bundles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Courses",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Courses", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Username = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    PasswordHash = table.Column<byte[]>(type: "varbinary(max)", nullable: false),
                    PasswordSalt = table.Column<byte[]>(type: "varbinary(max)", nullable: false),
                    Gender = table.Column<int>(type: "int", nullable: false),
                    Permissions = table.Column<int>(type: "int", nullable: false),
                    FirstName = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    PhoneNumber = table.Column<string>(type: "nvarchar(16)", maxLength: 16, nullable: false),
                    Country = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    City = table.Column<string>(type: "nvarchar(32)", maxLength: 32, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Classes",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    ClassStartAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ClassFinishAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CourseId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    LecturerId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Classes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Classes_Courses_CourseId",
                        column: x => x.CourseId,
                        principalTable: "Courses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Classes_Users_LecturerId",
                        column: x => x.LecturerId,
                        principalTable: "Users",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Sessions",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    UserId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ExpireAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sessions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Sessions_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ClassAssignments",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Title = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    AssignmentText = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ClassId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    EndSubmissionAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AssignmentBundleId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClassAssignments", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ClassAssignments_Bundles_AssignmentBundleId",
                        column: x => x.AssignmentBundleId,
                        principalTable: "Bundles",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClassAssignments_Classes_ClassId",
                        column: x => x.ClassId,
                        principalTable: "Classes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ClassMeetings",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Title = table.Column<string>(type: "nvarchar(56)", maxLength: 56, nullable: false),
                    MeetingUrl = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    ClassId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    LecturerId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    StartAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClassMeetings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ClassMeetings_Classes_ClassId",
                        column: x => x.ClassId,
                        principalTable: "Classes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ClassMeetings_Users_LecturerId",
                        column: x => x.LecturerId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ClassQuizzes",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Title = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ClassId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    IsOpen = table.Column<bool>(type: "bit", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClassQuizzes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ClassQuizzes_Classes_ClassId",
                        column: x => x.ClassId,
                        principalTable: "Classes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "UserClasses",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    StudentId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ClassId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Evaluation = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserClasses", x => x.Id);
                    table.ForeignKey(
                        name: "FK_UserClasses_Classes_ClassId",
                        column: x => x.ClassId,
                        principalTable: "Classes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UserClasses_Users_StudentId",
                        column: x => x.StudentId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ClassAssignmentSubmissions",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    StudentId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    AssignmentId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SubmissionText = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SubmittedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LecturerEvaluation = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: true),
                    LecturerNotes = table.Column<string>(type: "nvarchar(1024)", maxLength: 1024, nullable: true),
                    AssignmentSubmissionBundleId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClassAssignmentSubmissions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ClassAssignmentSubmissions_Bundles_AssignmentSubmissionBundleId",
                        column: x => x.AssignmentSubmissionBundleId,
                        principalTable: "Bundles",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_ClassAssignmentSubmissions_ClassAssignments_AssignmentId",
                        column: x => x.AssignmentId,
                        principalTable: "ClassAssignments",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ClassAssignmentSubmissions_Users_StudentId",
                        column: x => x.StudentId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ClassQuizQuestions",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Question = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: false),
                    QuizId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClassQuizQuestions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ClassQuizQuestions_ClassQuizzes_QuizId",
                        column: x => x.QuizId,
                        principalTable: "ClassQuizzes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ClassQuizSubmissions",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    QuizId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    StudentId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Score = table.Column<float>(type: "real", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClassQuizSubmissions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ClassQuizSubmissions_ClassQuizzes_QuizId",
                        column: x => x.QuizId,
                        principalTable: "ClassQuizzes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ClassQuizSubmissions_Users_StudentId",
                        column: x => x.StudentId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ClassQuizAnswers",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Answer = table.Column<string>(type: "nvarchar(80)", maxLength: 80, nullable: false),
                    IsRight = table.Column<bool>(type: "bit", nullable: false),
                    QuestionId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ClassQuizAnswers", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ClassQuizAnswers_ClassQuizQuestions_QuestionId",
                        column: x => x.QuestionId,
                        principalTable: "ClassQuizQuestions",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Courses",
                columns: new[] { "Id", "CreatedAt", "Description", "Name" },
                values: new object[,]
                {
                    { new Guid("8085339c-07b6-42be-ad10-7df5eb0564ce"), new DateTime(2022, 8, 14, 20, 31, 28, 453, DateTimeKind.Unspecified).AddTicks(3333), "Full Stack Development Microsoft .NET & ReactJS", "Data Structures and Algorithms" },
                    { new Guid("b21d2e8c-a9c9-4b25-a208-de40f2967b6d"), new DateTime(2022, 8, 14, 20, 27, 32, 723, DateTimeKind.Unspecified).AddTicks(3333), "Learn the fundamentals of programming and computer science concepts", "Introduction to Computer Science" }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "City", "Country", "CreatedAt", "Email", "FirstName", "Gender", "LastName", "PasswordHash", "PasswordSalt", "Permissions", "PhoneNumber", "Username" },
                values: new object[,]
                {
                    { new Guid("1fb83307-3f4d-4cf7-8df0-d2dc4f8d3860"), "New York", "America", new DateTime(2022, 8, 14, 19, 23, 47, 890, DateTimeKind.Unspecified).AddTicks(2802), "dani@gmail.com", "John", 1, "Doe", new byte[] { 115, 117, 78, 84, 104, 77, 90, 107, 83, 99, 99, 102, 65, 114, 67, 99, 103, 77, 102, 87, 97, 48, 109, 73, 57, 113, 50, 52, 103, 56, 109, 53, 70, 67, 121, 56, 116, 105, 117, 55, 111, 120, 112, 110, 86, 81, 57, 106, 102, 106, 105, 85, 57, 104, 110, 69, 56, 69, 76, 89, 77, 107, 110, 80, 100, 90, 106, 55, 52, 100, 122, 115, 53, 111, 119, 49, 66, 56, 49, 118, 80, 121, 86, 81, 85, 65, 61, 61 }, new byte[] { 108, 48, 76, 117, 74, 84, 109, 72, 80, 72, 76, 118, 47, 108, 88, 115, 120, 112, 77, 68, 115, 97, 73, 106, 52, 74, 51, 51, 54, 111, 85, 78, 81, 74, 85, 50, 86, 100, 76, 55, 80, 102, 56, 73, 109, 114, 120, 53, 80, 54, 47, 109, 120, 115, 119, 99, 116, 114, 85, 82, 73, 81, 79, 73, 76, 55, 57, 85, 83, 108, 104, 120, 65, 80, 68, 120, 53, 79, 75, 82, 115, 49, 89, 56, 103, 88, 51, 101, 48, 47, 70, 114, 57, 50, 74, 89, 73, 56, 72, 70, 81, 57, 109, 66, 84, 66, 55, 71, 100, 110, 51, 52, 67, 114, 52, 71, 75, 53, 48, 56, 50, 67, 74, 116, 90, 107, 121, 88, 115, 111, 119, 67, 114, 54, 67, 81, 117, 121, 106, 115, 86, 111, 74, 82, 79, 110, 119, 122, 102, 119, 89, 122, 56, 113, 104, 69, 110, 51, 87, 83, 104, 115, 99, 89, 90, 99, 48, 122, 114, 88, 65, 61 }, 1, "0542222221", "demo1" },
                    { new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "Lahore", "Pakistan", new DateTime(2022, 8, 13, 23, 22, 59, 582, DateTimeKind.Unspecified).AddTicks(6978), "alon@gmail.com", "Maryam", 1, "Jahangir", new byte[] { 78, 97, 88, 52, 104, 118, 53, 109, 82, 109, 113, 73, 101, 76, 78, 71, 79, 89, 76, 54, 70, 107, 47, 122, 99, 77, 71, 50, 77, 118, 50, 111, 65, 43, 65, 52, 115, 49, 83, 111, 122, 103, 100, 89, 83, 87, 115, 85, 84, 81, 117, 77, 103, 48, 108, 70, 111, 111, 67, 121, 54, 76, 76, 110, 102, 104, 83, 105, 115, 66, 82, 80, 90, 85, 97, 82, 105, 116, 100, 66, 88, 70, 65, 112, 71, 103, 61, 61 }, new byte[] { 57, 85, 105, 50, 56, 83, 115, 49, 100, 86, 122, 48, 43, 70, 85, 115, 54, 50, 86, 111, 82, 87, 117, 73, 99, 120, 99, 104, 48, 50, 119, 105, 117, 88, 101, 89, 101, 68, 98, 71, 99, 112, 56, 110, 69, 67, 117, 69, 69, 114, 79, 78, 102, 103, 69, 69, 51, 72, 103, 49, 49, 86, 115, 103, 118, 47, 86, 86, 104, 111, 110, 80, 73, 110, 79, 112, 74, 112, 79, 66, 119, 76, 75, 70, 98, 114, 119, 88, 72, 109, 71, 111, 57, 105, 55, 79, 55, 97, 83, 76, 101, 112, 69, 120, 71, 50, 77, 117, 85, 67, 118, 75, 67, 67, 79, 49, 120, 102, 112, 106, 98, 49, 106, 103, 85, 77, 76, 66, 78, 100, 47, 55, 113, 102, 84, 75, 122, 76, 119, 117, 112, 85, 108, 120, 54, 53, 121, 121, 114, 106, 43, 56, 84, 54, 51, 52, 69, 78, 43, 111, 104, 84, 80, 43, 99, 76, 102, 73, 107, 50, 73, 61 }, 2, "0542222222", "demo2" },
                    { new Guid("57b8ecbf-2475-4db1-9d36-ecc338d88445"), "Canada", "Europe", new DateTime(2022, 8, 19, 13, 0, 11, 768, DateTimeKind.Unspecified).AddTicks(2118), "admin@localhost.com", "Maryam", 2, "Yaqoob", new byte[] { 120, 65, 88, 75, 57, 101, 68, 72, 86, 48, 107, 81, 43, 89, 86, 102, 118, 106, 104, 86, 67, 55, 113, 108, 117, 77, 104, 57, 55, 69, 48, 86, 49, 103, 87, 111, 77, 81, 84, 116, 115, 99, 109, 101, 109, 98, 53, 86, 54, 65, 111, 70, 68, 104, 81, 73, 84, 75, 122, 111, 74, 78, 85, 87, 81, 119, 83, 68, 108, 43, 120, 43, 106, 122, 106, 106, 107, 76, 49, 47, 110, 90, 111, 104, 97, 81, 61, 61 }, new byte[] { 101, 79, 87, 119, 103, 51, 108, 89, 48, 105, 97, 98, 67, 83, 78, 114, 105, 122, 76, 79, 101, 105, 57, 53, 79, 55, 76, 72, 113, 108, 107, 73, 112, 98, 115, 80, 107, 105, 78, 67, 105, 99, 54, 79, 80, 57, 110, 73, 101, 85, 66, 54, 80, 110, 110, 110, 90, 84, 111, 49, 73, 84, 67, 81, 99, 74, 101, 121, 75, 65, 87, 110, 119, 49, 109, 66, 100, 90, 57, 52, 107, 52, 48, 114, 82, 77, 67, 121, 56, 114, 67, 108, 57, 109, 67, 48, 98, 107, 51, 43, 76, 101, 97, 54, 53, 56, 43, 120, 88, 81, 116, 88, 115, 113, 113, 76, 110, 103, 100, 57, 120, 84, 108, 98, 55, 109, 115, 104, 102, 73, 57, 55, 99, 114, 119, 103, 76, 52, 51, 118, 98, 75, 78, 115, 111, 122, 89, 69, 53, 79, 49, 66, 104, 101, 56, 73, 71, 72, 107, 47, 82, 103, 84, 71, 118, 120, 72, 51, 65, 114, 111, 61 }, 3, "1111111111", "demo3" }
                });

            migrationBuilder.InsertData(
                table: "Classes",
                columns: new[] { "Id", "ClassFinishAt", "ClassStartAt", "CourseId", "CreatedAt", "LecturerId", "Name" },
                values: new object[] { new Guid("323a5ad6-7c0b-4e94-b55e-0e56282d9b4f"), new DateTime(2022, 8, 16, 14, 52, 38, 210, DateTimeKind.Unspecified), new DateTime(2022, 8, 16, 14, 52, 38, 210, DateTimeKind.Unspecified), new Guid("8085339c-07b6-42be-ad10-7df5eb0564ce"), new DateTime(2022, 8, 16, 14, 52, 38, 210, DateTimeKind.Unspecified), null, "D151121MR" });

            migrationBuilder.InsertData(
                table: "Classes",
                columns: new[] { "Id", "ClassFinishAt", "ClassStartAt", "CourseId", "CreatedAt", "LecturerId", "Name" },
                values: new object[] { new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 14, 52, 19, 930, DateTimeKind.Unspecified), new DateTime(2022, 8, 16, 14, 52, 19, 930, DateTimeKind.Unspecified), new Guid("8085339c-07b6-42be-ad10-7df5eb0564ce"), new DateTime(2022, 8, 16, 14, 52, 19, 930, DateTimeKind.Unspecified), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "D151121ER" });

            migrationBuilder.InsertData(
                table: "Classes",
                columns: new[] { "Id", "ClassFinishAt", "ClassStartAt", "CourseId", "CreatedAt", "LecturerId", "Name" },
                values: new object[] { new Guid("9a6befae-bfe1-4b01-a4fc-2805d4043df7"), new DateTime(2022, 8, 16, 15, 56, 0, 243, DateTimeKind.Unspecified).AddTicks(3333), new DateTime(2022, 8, 16, 15, 56, 0, 243, DateTimeKind.Unspecified).AddTicks(3333), new Guid("b21d2e8c-a9c9-4b25-a208-de40f2967b6d"), new DateTime(2022, 8, 16, 15, 56, 0, 243, DateTimeKind.Unspecified).AddTicks(3333), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "G160822ER" });

            migrationBuilder.InsertData(
                table: "ClassMeetings",
                columns: new[] { "Id", "ClassId", "CreatedAt", "LecturerId", "MeetingUrl", "StartAt", "Title" },
                values: new object[,]
                {
                    { new Guid("000b4f7a-8adf-44db-8081-1fc99845c261"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 11, 330, DateTimeKind.Unspecified), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 14, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("01d65ce9-2754-470c-9967-16446c37b8e4"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 2, 260, DateTimeKind.Unspecified), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 8, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("12d7d085-0271-48c1-b871-bf6e6afc3da0"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 6, 463, DateTimeKind.Unspecified).AddTicks(3333), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 10, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("21d85b05-409e-4da2-a47f-a4d2407a55f5"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 24, 836, DateTimeKind.Unspecified).AddTicks(6667), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 24, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("370704d4-cfae-421b-8d46-a75af528a52a"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 28, 686, DateTimeKind.Unspecified).AddTicks(6667), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 27, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("397aadb6-25d6-4948-97e5-e822994ab562"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 22, 186, DateTimeKind.Unspecified).AddTicks(6667), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 22, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("44772e5b-1cd0-4383-a577-b6fa874e6ab6"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 14, 58, 39, 780, DateTimeKind.Unspecified), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 8, 17, 17, 30, 0, 0, DateTimeKind.Unspecified), "Learn classes and OOP" },
                    { new Guid("4cc825da-6108-4707-85a4-e7574310e5f6"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 15, 196, DateTimeKind.Unspecified).AddTicks(6667), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 17, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("4eb0f4c8-3bb6-4213-8cbf-9761a1c064fa"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 14, 59, 54, 896, DateTimeKind.Unspecified).AddTicks(6667), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 3, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("4eba53af-e916-4f26-acb5-0938a085c61c"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 17, 710, DateTimeKind.Unspecified), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 18, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("52178fa5-abcd-4e7f-bcb2-c494b7f2ba98"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 20, 233, DateTimeKind.Unspecified).AddTicks(3333), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 20, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("5e2c5167-9c37-475d-b8c0-7a426e10a02e"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 26, 140, DateTimeKind.Unspecified), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 25, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("60e35fe8-48c4-459d-ace4-5cc242ac6cb1"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 14, 59, 57, 346, DateTimeKind.Unspecified).AddTicks(6667), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 5, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("6471d929-92ff-4555-ad3f-7d3d57e9cb98"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 21, 233, DateTimeKind.Unspecified).AddTicks(3333), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 21, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("6b2385d4-2119-4b86-ba4b-ddfa0e8a3e45"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 12, 563, DateTimeKind.Unspecified).AddTicks(3333), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 15, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("6f878d02-9365-433a-8516-6d7b34d2541e"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 27, 690, DateTimeKind.Unspecified), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 26, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("75c147aa-1076-4b76-82b8-2c62bbe52695"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 29, 730, DateTimeKind.Unspecified), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 28, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("78ae0eb1-cd66-4487-a49d-38539dfdef4b"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 14, 58, 13, 133, DateTimeKind.Unspecified).AddTicks(3333), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 8, 16, 8, 52, 38, 210, DateTimeKind.Unspecified), "Learn .NET basics" },
                    { new Guid("88c52c24-57dd-4505-b3e7-4f1e57be5afd"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 18, 853, DateTimeKind.Unspecified).AddTicks(3333), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 19, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("97dc3d25-d3d7-4d3b-8219-bdf23db0e5c7"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 8, 663, DateTimeKind.Unspecified).AddTicks(3333), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 12, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("9de9a4ae-eb7e-478f-9ef0-f119da36ba23"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 23, 726, DateTimeKind.Unspecified).AddTicks(6667), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 23, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("aca3e42b-2958-4a08-8bae-81a58efe8abb"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 30, 736, DateTimeKind.Unspecified).AddTicks(6667), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 29, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("adcf54e6-f884-4765-8829-6835eea6ace2"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 0, 940, DateTimeKind.Unspecified), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 7, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("af1c538f-5c57-4c8b-9a00-39be3a1c7d69"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 33, 146, DateTimeKind.Unspecified).AddTicks(6667), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 30, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("c322a345-3ab5-47ea-b34a-9b0ebdfe99dc"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 10, 190, DateTimeKind.Unspecified), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 13, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("cc3fc18c-c029-4811-aafd-990c8cb3e95b"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 13, 933, DateTimeKind.Unspecified).AddTicks(3333), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 16, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("d4b7f3e6-3671-4ebe-8d13-d7f1d065f76b"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 14, 59, 56, 40, DateTimeKind.Unspecified), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 4, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("da346543-0244-4b83-b756-9385cd9b5e47"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 3, 496, DateTimeKind.Unspecified).AddTicks(6667), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 9, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("e99cd14b-af7f-42a2-b619-c3306f9e6e51"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 14, 59, 53, 566, DateTimeKind.Unspecified).AddTicks(6667), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 2, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("eccd87e1-cc0b-41a5-9fdd-e855ae1cca91"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 14, 59, 59, 350, DateTimeKind.Unspecified), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 6, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("f296539b-772b-4aa6-8346-7e36fb6e70db"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 15, 0, 7, 493, DateTimeKind.Unspecified).AddTicks(3333), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 11, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" },
                    { new Guid("f9607d6b-c557-4801-81a9-b532bc9fa3d0"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 14, 59, 13, 36, DateTimeKind.Unspecified).AddTicks(6667), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 8, 25, 17, 30, 0, 0, DateTimeKind.Unspecified), "Learn LINQ" },
                    { new Guid("fdc4ec99-271b-457d-a867-040778b1e50a"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 14, 59, 50, 650, DateTimeKind.Unspecified), new Guid("432d6f99-d2bf-4267-959f-1a039c950e0f"), "https://us06web.zoom.us/j/83663882593", new DateTime(2022, 9, 1, 17, 30, 0, 0, DateTimeKind.Unspecified), "Generic meeting" }
                });

            migrationBuilder.InsertData(
                table: "UserClasses",
                columns: new[] { "Id", "ClassId", "CreatedAt", "Evaluation", "StudentId" },
                values: new object[,]
                {
                    { new Guid("4b500d50-f6d5-49b9-8cb8-b9dc0646ae7f"), new Guid("9a6befae-bfe1-4b01-a4fc-2805d4043df7"), new DateTime(2022, 8, 16, 15, 57, 2, 686, DateTimeKind.Unspecified).AddTicks(6667), null, new Guid("1fb83307-3f4d-4cf7-8df0-d2dc4f8d3860") },
                    { new Guid("870f4bc7-7b75-44ae-9e9d-e0337693eb0e"), new Guid("7c129914-4625-46d3-b11d-3a6f122ace07"), new DateTime(2022, 8, 16, 14, 54, 46, 870, DateTimeKind.Unspecified), null, new Guid("1fb83307-3f4d-4cf7-8df0-d2dc4f8d3860") }
                });

            migrationBuilder.CreateIndex(
                name: "IX_ClassAssignments_AssignmentBundleId",
                table: "ClassAssignments",
                column: "AssignmentBundleId");

            migrationBuilder.CreateIndex(
                name: "IX_ClassAssignments_ClassId",
                table: "ClassAssignments",
                column: "ClassId");

            migrationBuilder.CreateIndex(
                name: "IX_ClassAssignmentSubmissions_AssignmentId",
                table: "ClassAssignmentSubmissions",
                column: "AssignmentId");

            migrationBuilder.CreateIndex(
                name: "IX_ClassAssignmentSubmissions_AssignmentSubmissionBundleId",
                table: "ClassAssignmentSubmissions",
                column: "AssignmentSubmissionBundleId");

            migrationBuilder.CreateIndex(
                name: "IX_ClassAssignmentSubmissions_StudentId",
                table: "ClassAssignmentSubmissions",
                column: "StudentId");

            migrationBuilder.CreateIndex(
                name: "IX_Classes_CourseId",
                table: "Classes",
                column: "CourseId");

            migrationBuilder.CreateIndex(
                name: "IX_Classes_LecturerId",
                table: "Classes",
                column: "LecturerId");

            migrationBuilder.CreateIndex(
                name: "IX_ClassMeetings_ClassId",
                table: "ClassMeetings",
                column: "ClassId");

            migrationBuilder.CreateIndex(
                name: "IX_ClassMeetings_LecturerId",
                table: "ClassMeetings",
                column: "LecturerId");

            migrationBuilder.CreateIndex(
                name: "IX_ClassQuizAnswers_QuestionId",
                table: "ClassQuizAnswers",
                column: "QuestionId");

            migrationBuilder.CreateIndex(
                name: "IX_ClassQuizQuestions_QuizId",
                table: "ClassQuizQuestions",
                column: "QuizId");

            migrationBuilder.CreateIndex(
                name: "IX_ClassQuizSubmissions_QuizId",
                table: "ClassQuizSubmissions",
                column: "QuizId");

            migrationBuilder.CreateIndex(
                name: "IX_ClassQuizSubmissions_StudentId",
                table: "ClassQuizSubmissions",
                column: "StudentId");

            migrationBuilder.CreateIndex(
                name: "IX_ClassQuizzes_ClassId",
                table: "ClassQuizzes",
                column: "ClassId");

            migrationBuilder.CreateIndex(
                name: "IX_Sessions_UserId",
                table: "Sessions",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_UserClasses_ClassId",
                table: "UserClasses",
                column: "ClassId");

            migrationBuilder.CreateIndex(
                name: "IX_UserClasses_StudentId",
                table: "UserClasses",
                column: "StudentId");

            migrationBuilder.CreateIndex(
                name: "IX_Users_Email",
                table: "Users",
                column: "Email",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Users_Username",
                table: "Users",
                column: "Username",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ClassAssignmentSubmissions");

            migrationBuilder.DropTable(
                name: "ClassMeetings");

            migrationBuilder.DropTable(
                name: "ClassQuizAnswers");

            migrationBuilder.DropTable(
                name: "ClassQuizSubmissions");

            migrationBuilder.DropTable(
                name: "Sessions");

            migrationBuilder.DropTable(
                name: "UserClasses");

            migrationBuilder.DropTable(
                name: "ClassAssignments");

            migrationBuilder.DropTable(
                name: "ClassQuizQuestions");

            migrationBuilder.DropTable(
                name: "Bundles");

            migrationBuilder.DropTable(
                name: "ClassQuizzes");

            migrationBuilder.DropTable(
                name: "Classes");

            migrationBuilder.DropTable(
                name: "Courses");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
