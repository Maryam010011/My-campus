﻿namespace MyCampusUI.Exceptions
{
    public class QuizCreateException : ApplicationException
    {
        public QuizCreateException(string message) : base(message)
        {
        }
    }
}
