﻿namespace MyCampusUI.Exceptions
{
    public class AssignmentDeleteException : ApplicationException
    {
        public AssignmentDeleteException(string message) : base(message)
        {
        }
    }
}
