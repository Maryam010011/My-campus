﻿namespace MyCampusUI.Exceptions
{
    public class QuizSubmitException : ApplicationException
    {
        public QuizSubmitException(string message) : base(message)
        {
        }
    }
}
