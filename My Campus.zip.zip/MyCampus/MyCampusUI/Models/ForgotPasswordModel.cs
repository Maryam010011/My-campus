using System.ComponentModel.DataAnnotations;

namespace MyCampusUI.Models
{
    public class ForgotPasswordModel
    {
        [Required, EmailAddress]
        public string Email { get; set; } = "";
    }
} 