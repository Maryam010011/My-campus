﻿namespace MyCampusUI.Exceptions
{
    public class AssignmentSubmitException : ApplicationException
    {
        public AssignmentSubmitException(string message) : base(message)
        {
        }
    }
}
