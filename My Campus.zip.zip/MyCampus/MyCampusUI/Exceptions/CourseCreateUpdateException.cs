﻿namespace MyCampusUI.Exceptions
{
    public class CourseCreateUpdateException : ApplicationException
    {
        public CourseCreateUpdateException(string message) : base(message)
        {
        }
    }
}
