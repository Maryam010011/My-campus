﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace MyCampusData.Helpers
{
    public class ByteArrayConverter : JsonConverter<byte[]>
    {
        public override byte[] Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            string? value = reader.GetString();
            if (string.IsNullOrEmpty(value))
                return Array.Empty<byte>();

            // Convert the string to bytes using UTF8 encoding
            return Encoding.UTF8.GetBytes(value);
        }

        public override void Write(Utf8JsonWriter writer, byte[] value, JsonSerializerOptions options)
        {
            writer.WriteStringValue(Convert.ToBase64String(value));
        }
    }

    public class GuidConverter : JsonConverter<Guid>
    {
        public override Guid Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            string? value = reader.GetString();
            if (string.IsNullOrEmpty(value))
                throw new JsonException("GUID value cannot be null or empty");

            // First try to parse as a regular GUID
            if (Guid.TryParse(value, out Guid result))
                return result;

            // If that fails, convert the string to a deterministic GUID
            using (var md5 = MD5.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(value);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                return new Guid(hashBytes);
            }
        }

        public override void Write(Utf8JsonWriter writer, Guid value, JsonSerializerOptions options)
        {
            writer.WriteStringValue(value.ToString("D"));
        }
    }

    public static class SeedHelper
    {
        private static readonly JsonSerializerOptions _jsonOptions = new JsonSerializerOptions
        {
            PropertyNameCaseInsensitive = true,
            Converters = 
            { 
                new JsonStringEnumConverter(),
                new GuidConverter(),
                new ByteArrayConverter()
            }
        };

        public static List<TEntity> SeedData<TEntity>(string fileName)
        {
            string? currentDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            if(currentDirectory == null) throw new DirectoryNotFoundException("Assembly directory not found");
            string path = "seed";
            string fullPath = Path.Combine(currentDirectory, @"..\..\..\..\", nameof(MyCampusData), path, fileName);

            var result = new List<TEntity>();
            using (StreamReader reader = new StreamReader(fullPath))
            {
                string json = reader.ReadToEnd();
                result = JsonSerializer.Deserialize<List<TEntity>>(json, _jsonOptions);

                if (result == null)
                    throw new NullReferenceException("Error while parsing json file");
            }

            return result;
        }
    }
}
