﻿namespace MyCampusUI.Exceptions
{
    public class QuizToggleStatusException : ApplicationException
    {
        public QuizToggleStatusException(string message) : base(message)
        {
        }
    }
}
