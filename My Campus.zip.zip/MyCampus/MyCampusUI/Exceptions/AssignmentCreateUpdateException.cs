﻿namespace MyCampusUI.Exceptions
{
    public class AssignmentCreateUpdateException : ApplicationException
    {
        public AssignmentCreateUpdateException(string message) : base(message)
        {
        }
    }
}
