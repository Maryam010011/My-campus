﻿namespace MyCampusUI.Exceptions
{
    public class QuizDeleteException : ApplicationException
    {
        public QuizDeleteException(string message) : base(message)
        {
        }
    }
}
