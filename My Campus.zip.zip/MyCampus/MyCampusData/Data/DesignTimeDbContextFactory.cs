using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace MyCampusData.Data
{
    public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<CampusContext>
    {
        public CampusContext CreateDbContext(string[] args)
        {
            IConfigurationRoot configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json")
                .Build();

            var builder = new DbContextOptionsBuilder<CampusContext>();
            var connectionString = configuration.GetConnectionString("CampusDatabase");

            builder.UseSqlServer(connectionString);

            return new CampusContext(configuration);
        }
    }
} 